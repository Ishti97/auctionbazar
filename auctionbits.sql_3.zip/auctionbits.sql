-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2022 at 04:43 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auctionbits`
--

-- --------------------------------------------------------

--
-- Table structure for table `bidder`
--

CREATE TABLE `bidder` (
  `Username` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `ContactNo` int(20) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Identity` varchar(20) NOT NULL DEFAULT 'bidder'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bidder`
--

INSERT INTO `bidder` (`Username`, `Email`, `Password`, `ContactNo`, `Designation`, `Image`, `Identity`) VALUES
('bodi', 'bodi@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 2147483647, 'driver', '2090777908', 'bidder'),
('ishti', 'ishti@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 5535121, 'Student', '512139857257157522quotes.jpg', 'bidder'),
('jisan', 'jisan@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 0, '', '769546290', 'bidder'),
('joy', 'joy@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 12345688, 'student', '10767431642104521467pexels-adrien-olichon-2387793.jpg', 'bidder'),
('Nafim', 'nafim@gmail.com', '81dc9bdb52d04dc20036', 116446, 'student', '2706999162104521467pexels-adrien-olichon-2387793.jpg', 'bidder'),
('tahlil', 'tahlil@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 42332, 'student', '1528662333', 'bidder');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `Id` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Content` varchar(2000) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Author` varchar(255) NOT NULL,
  `DateTime` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`Id`, `Title`, `Content`, `Image`, `Author`, `DateTime`) VALUES
(5, '1st', 'It was going to rain. The weather forecast didn\'t say that, but the steel plate in his hip did. He had learned over the years to trust his hip over the weatherman. It was going to rain, so he better get outside and prepare.', '972739029854054395quotes.jpg', 'bodi@gmail.com', '2022-05-10'),
(6, 'Thoughts', 'He scolded himself for being so tentative. He knew he shouldn\'t be so cautious, but there was a sixth sense telling him that things weren\'t exactly as they appeared. It was that weird chill that rolls up your neck and makes the hair stand on end. He knew that being so tentative could end up costing him the job, but he learned that listening to his sixth sense usually kept him from getting into a lot of trouble.', '2073665433default.jpg', 'bodi@gmail.com', '2022-05-10'),
(7, 'Weather Demand', 'It was their first date and she had been looking forward to it the entire week. She had her eyes on him for months, and it had taken a convoluted scheme with several friends to make it happen, but he\'d finally taken the hint and asked her out. After all the time and effort she\'d invested into it, she never thought that it would be anything but wonderful. It goes without saying that things didn\'t work out quite as she expected.', '10766716724.png', 'bodi@gmail.com', '2022-05-11'),
(8, 'post', 'hello', '1202635951854054395quotes.jpg', 'ishti@gmail.com', '2022-05-11'),
(9, 'huddie', 'tut', '1861547836d5250a0e7ba06dd6707f0bf18ae9eb8.jpg', 'ishti@gmail.com', '2022-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `ProductId` int(255) NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Price` int(255) NOT NULL,
  `Buyer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`ProductId`, `ProductName`, `Price`, `Buyer`) VALUES
(54, 'Table', 700, 'bodi'),
(61, 'pen', 90, 'bodi'),
(69, 'Bat', 555, 'bodi'),
(8, 'Antique chair', 320, 'bodi'),
(3239, 'Ancient Horse', 700, 'jisan'),
(3238, 'Pokemon', 50, 'jisan'),
(3238, 'Pokemon', 50, 'jisan'),
(3237, 'Table', 80, ''),
(3244, 'Huddie', 320, ''),
(3246, 'Huddie', 50, 'ishti'),
(3251, 'Table', 70000, 'ishti'),
(3251, 'Table', 70000, 'ishti');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment` varchar(200) NOT NULL,
  `sender` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `postId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment`, `sender`, `date`, `postId`) VALUES
('Good one!', 'arif', '2022-05-22 20:53:33', 5),
('Good one!', 'arif', '2022-05-23 03:57:05', 6),
('This is beautiful!', 'jisan', '2022-05-23 04:33:12', 5);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Id` int(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Category` varchar(255) NOT NULL,
  `Description` varchar(120) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `rating` double NOT NULL,
  `rated_by` int(11) NOT NULL,
  `eventdt` timestamp NULL DEFAULT NULL,
  `Status` varchar(255) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Id`, `Price`, `Name`, `Category`, `Description`, `Image`, `rating`, `rated_by`, `eventdt`, `Status`) VALUES
(3237, 80, 'Table', 'Antique', 'Table is from 1999 old collection...', '19923954table.jpg', 4.1, 2, '2022-05-23 12:31:00', 'approved'),
(3239, 720, 'Ancient Horse', 'Art', 'Sweden edition 1995', '236683550ancient horse.jpeg', 0, 0, '2022-05-25 07:40:00', 'approved'),
(3244, 90, 'Huddie', 'others', 'Good', '16420523936d5250a0e7ba06dd6707f0bf18ae9eb8.jpg', 3.4, 2, '2025-08-04 21:55:00', 'approved'),
(3251, 70000, 'Table', 'antique', 'Good', '27915518119923954table.jpg', 0, 0, '2022-09-13 07:33:00', 'approved'),
(3252, 50000, 'Huddie', 'others', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard ', '14239175961851517116d5250a0e7ba06dd6707f0bf18ae9eb8.jpg', 0, 0, '2022-09-16 08:37:00', 'approved'),
(3253, 555, 'Table', 'antique', 'Table is from 1999 old collection...', '155797718619923954table.jpg', 0, 0, '2022-09-29 21:54:00', 'approved'),
(3254, 120, 'Watch', 'antique', 'Watch , most elegant one', '1607279643520177729watch.jpeg', 0, 0, '2022-10-02 21:57:00', 'approved'),
(3255, 444, 'Horse', 'sports', '1990\'s', '1274085635236683550ancient horse.jpeg', 0, 0, '2022-09-28 21:57:00', 'approved'),
(3256, 50, 'Marin', 'sports', 'Marin ', '21292064982031019402marin.jpg', 0, 0, '2022-09-29 22:19:00', 'approved'),
(3257, 79, 'Lufi', 'sports', 'Lufi', '1139492394696185607lufi.jpg', 0, 0, '2022-10-02 22:19:00', 'approved'),
(3259, 120, 'Light', 'others', '1990\'s', '14039804712101442754light.jpeg', 0, 0, '2022-09-23 22:21:00', 'approved'),
(3260, 120, 'Light', 'antique', 'Good', '1020847262101442754light.jpeg', 0, 0, '2022-09-23 22:23:00', 'pending'),
(3262, 555, 'Watch', 'antique', '1990\'s', '1575964365520177729watch.jpeg', 0, 0, '2022-09-29 20:08:00', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `Username` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `ContactNo` int(20) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Identity` varchar(20) NOT NULL DEFAULT 'seller'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`Username`, `Email`, `Password`, `ContactNo`, `Designation`, `Image`, `Identity`) VALUES
('arif', 'arif@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 2147483647, 'teacher', '1028897197', 'seller'),
('bhai', 'bhai@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 0, '', '1418566199', 'seller'),
('jack', 'jack@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 245254637, 'teacher', '21358077891030455187pexels-adrien-olichon-2387793.jpg', 'seller'),
('Nafim', 'nafim@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 116446, 'student', '1175761242978919845pexels-adrien-olichon-2387793.jpg', 'seller');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `State` varchar(255) NOT NULL,
  `PostCode` int(255) NOT NULL,
  `StreetAddress` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `ShippingMethod` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`Id`, `Email`, `FirstName`, `LastName`, `Country`, `State`, `PostCode`, `StreetAddress`, `Phone`, `ShippingMethod`) VALUES
(1, 'bodi@gmail.com', 'Bodi', 'Linux', 'Bangladesh', 'Dhaka', 1212, '100 Feet', '0123456', '1'),
(2, '', '', '', '', '', 0, '', '', '3'),
(3, '', '', '', '', '', 0, '', '', '2'),
(4, 'john@gmail.com', 'John', 'Doe', 'BD', 'Dhk', 1212, '100 feet', '124355', '1'),
(5, '', '', '', '', '', 0, '', '', '1'),
(6, '', '', '', '', '', 0, '', '', '1'),
(7, '', '', '', '', '', 0, '', '', '1'),
(8, '', '', '', '', '', 0, '', '', '1'),
(9, '', '', '', '', '', 0, '', '', '1'),
(10, '', '', '', '', '', 0, '', '', '1'),
(11, 'ishti@gmail.com', 'Bodi', 'Linux', 'Bangladesh', 'Dhaka', 1212, '100 Feet', '0123456', '1'),
(12, '', '', '', '', '', 0, '', '', '1'),
(13, '', '', '', '', '', 0, '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `winner`
--

CREATE TABLE `winner` (
  `Id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `winner`
--

INSERT INTO `winner` (`Id`, `username`, `bid`) VALUES
(3236, 'bodi', 0),
(3236, 'bodi', 666),
(3236, 'bodi', 777),
(8, 'ishti', 500),
(8, 'ishti', 666),
(8, 'ishti', 700),
(54, 'ishti', 666),
(3239, 'arif', 700),
(3239, 'bodi', 720),
(3243, 'bodi', 75),
(3237, 'bodi', 90),
(3237, 'jisan', 100),
(3237, 'jisan', 80),
(3244, 'ishti', 700),
(3244, '', 340),
(3244, '', 320),
(3244, '', 90),
(3244, '', 20),
(3244, '', 10),
(3244, '', 340),
(3244, '', 390),
(3244, '', 300),
(3244, '', 20),
(3244, '', 666),
(3244, '', 300),
(3244, '', 22),
(3244, '', 1111),
(3244, '', 320),
(3244, '', 300),
(3244, '', 90),
(3244, '', 32),
(3245, 'ishti', 600),
(3250, 'arif', 100),
(3250, '', 50),
(3250, '', 40),
(3250, '', 39),
(3250, '', 40),
(3251, 'arif', 70000),
(3252, 'ishti', 666),
(3252, 'ishti', 700),
(3252, 'ishti', 700),
(3252, 'ishti', 1000),
(3252, 'ishti', 2000),
(3252, 'ishti', 2000),
(3252, 'ishti', 2000),
(3252, 'ishti', 5000),
(3252, 'ishti', 50000),
(3244, 'ishti', 90);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bidder`
--
ALTER TABLE `bidder`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3263;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `CommentOfPost` FOREIGN KEY (`postId`) REFERENCES `blog` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
